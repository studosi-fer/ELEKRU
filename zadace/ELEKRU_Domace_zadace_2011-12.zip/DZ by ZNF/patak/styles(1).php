/**************************************
 * THEME NAME: standardwhite
 *
 * Files included in this sheet:
 *
 *   standardwhite/gradients.css
 **************************************/

/***** standardwhite/gradients.css start *****/

/**
  *  Adds all the nice finish to the standard theme
  *
  */

th.header,
td.header,
h1.header,
h2.header,
h3.header,
div.header {     
    background-image:url(gradient.jpg);     
    background-position:top;    
    background-repeat:repeat-x;     
}

.navbar {
    background-image:url(gradient.jpg);     
    background-position:top;    
    background-repeat:repeat-x;     
}
/***** standardwhite/gradients.css end *****/

